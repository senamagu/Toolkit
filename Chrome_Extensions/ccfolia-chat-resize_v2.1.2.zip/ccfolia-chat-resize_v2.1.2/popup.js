// ポップアップが開いた時に初期化
document.addEventListener("DOMContentLoaded", () => {

  // 今開いているタブを取得
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || !tabs[0] || !tabs[0].url) return;

    const currentTab = tabs[0];

    // ルームIDをURLから取り出す
    const getRoomId = (url) => {
      const m = url.match(/\/rooms\/([^/]+)/);
      return m ? m[1] : "unknown";
    };

    const roomId = getRoomId(currentTab.url);

    // ルームごとの保存キー
    const STORAGE_KEY = `chatWidth_${roomId}`;

    // UI要素を取得
    const slider = document.getElementById("widthSlider");
    const display = document.getElementById("display");
    if (!slider || !display) return;

    // ===== 保存値の反映 =====
    // 以前保存した幅を読み込み、スライダーと表示に反映
    chrome.storage.local.get([STORAGE_KEY], (res) => {
      const savedWidth = Number(res[STORAGE_KEY] ?? 520);
      slider.value = String(savedWidth);
      display.innerText = String(savedWidth);
    });

    // ===== スライダー操作 =====
    // 動かした時に幅を保存＆ページに送信
    slider.addEventListener("input", () => {
      const val = Number(slider.value);
      display.innerText = String(val);

      // 幅を保存
      chrome.storage.local.set({ [STORAGE_KEY]: val });

      // Content Scriptへ通知
      chrome.tabs.sendMessage(currentTab.id, { type: "UPDATE_WIDTH", value: val }, () => {
        // content script が無い場合のエラーを無視
        void chrome.runtime.lastError;
      });
    });
  });
});
