// ===== 基本設定 =====
// チャット幅の制限値
const MIN_WIDTH = 280;
const MAX_WIDTH = 1200;
const DEFAULT_WIDTH = 520;

// ココフォリアUIの主要セレクタ
// ※アップデートで変わる可能性があるのでまとめて管理
const DRAWER_SELECTOR = ".MuiDrawer-root"; 
const DRAWER_PAPER_SELECTOR = ".MuiDrawer-paper";
const MAIN_CONTAINER_SELECTOR = ".sc-geBDJh.iTYDax";
const HEADER_SPACER_SELECTOR = "header .sc-gJjChS";

// 最後に適用した幅を記憶（再描画時に復元するため）
let lastWidth = DEFAULT_WIDTH;


// ===== ルームごとの保存キー =====
// URLからルームIDを抽出して保存キーを作る
const getRoomId = () => {
    const m = location.pathname.match(/^\/rooms\/([^/]+)/);
    return m ? m[1] : "unknown";
};
const STORAGE_KEY = `chatWidth_${getRoomId()}`;


// ===== CSS注入の準備 =====
// チャット幅を書き換えるためのstyleタグを作成
let resizerStyle = document.getElementById('ccfolia-drag-resizer-style');
if (!resizerStyle) {
    resizerStyle = document.createElement('style');
    resizerStyle.id = 'ccfolia-drag-resizer-style';
    document.head.appendChild(resizerStyle);
}


// ===== ドラッグ状態 =====
// ドラッグ中かどうか（observer暴走防止用）
let isDragging = false;


// ===== 幅を適用する本体 =====
// CSSを書き換えてチャット幅を反映
function applyWidth(px) {
    const w = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, px));

    // チャットが開いているか判定
    const paperRight = document.querySelector(".MuiDrawer-paperAnchorRight");
    const rect = paperRight ? paperRight.getBoundingClientRect() : null;
    const isChatOpen = !!rect && rect.left < window.innerWidth - 1;

    // 開いていない時は余白を0に戻す
    const rightW = isChatOpen ? w : 0;
    
    resizerStyle.innerHTML = `
      .MuiDrawer-paperAnchorRight, .sc-lfRwWD {
          width: ${w}px !important;
          min-width: ${w}px !important;
          max-width: ${w}px !important;
          flex: 0 0 ${w}px !important;
      }
  
      .sc-geBDJh.iTYDax {
          right: ${rightW}px !important;
      }

      header .sc-gJjChS {
          width: ${rightW}px !important;
          min-width: ${rightW}px !important;
      }

      .sc-cxyaiY.cMXExF { right: 10px !important; left: auto !important; }
      .sc-cKhha-d.extLAb, .sc-kMGnbm.bsyoTg { right: 20px !important; left: auto !important; }
  `;

    return document.querySelector(DRAWER_SELECTOR) !== null;
}


// ===== 保存 =====
// 幅をローカルストレージに保存
const saveWidth = (px) => {
    chrome.storage.local.set({ [STORAGE_KEY]: px });
};


// ===== ドラッグハンドル生成 =====
// チャット左端にドラッグUIを追加
function ensureHandle() {
    if (document.getElementById("cc-chat-drag-handle")) return;

    const chat = document.querySelector(DRAWER_PAPER_SELECTOR) || document.querySelector(DRAWER_SELECTOR);
    if (!chat) return;

    const handle = document.createElement("div");
    handle.id = "cc-chat-drag-handle";
    handle.title = "ドラッグで幅を変更";
    handle.style.cssText = `
        position: absolute;
        top: 0;
        left: -5px;
        width: 10px;
        height: 100%;
        cursor: ew-resize;
        z-index: 10000;
        background: transparent;
    `;
    
    const line = document.createElement("div");
    line.style.cssText = `
        position: absolute;
        left: 4px;
        width: 2px;
        height: 100%;
        background: rgba(255, 255, 255, 0.5);
        opacity: 0;
        transition: opacity 0.2s;
        pointer-events: none;
    `;
    handle.appendChild(line);

    handle.onmouseenter = () => line.style.opacity = "1";
    handle.onmouseleave = () => { if (!isDragging) line.style.opacity = "0"; };

    chat.appendChild(handle);

    // ===== ドラッグ中処理 =====
    const onMouseMove = (e) => {
        if (!isDragging) return;
        const newWidth = window.innerWidth - e.clientX;
        applyWidth(newWidth);
    };

    // ===== ドラッグ終了 =====
    const onMouseUp = (e) => {
        if (!isDragging) return;
        isDragging = false;
        line.style.opacity = "0";
        document.body.style.cursor = "";
        const finalWidth = window.innerWidth - e.clientX;
        lastWidth = finalWidth;
        saveWidth(finalWidth);
        window.removeEventListener("mousemove", onMouseMove);
        window.removeEventListener("mouseup", onMouseUp);
    };

    handle.addEventListener("mousedown", (e) => {
        e.preventDefault();
        isDragging = true;
        document.body.style.cursor = "ew-resize";
        window.addEventListener("mousemove", onMouseMove);
        window.addEventListener("mouseup", onMouseUp);
    });
}


// ===== 初期化 =====
// 保存された幅を読み込み＆再描画監視を開始
function init() {
    chrome.storage.local.get([STORAGE_KEY], (res) => {
        const savedWidth = res[STORAGE_KEY] || DEFAULT_WIDTH;
        lastWidth = savedWidth;

        // 要素が揃うまで定期適用
        const timer = setInterval(() => {
            const success = applyWidth(lastWidth);
            if (success) {
                ensureHandle();
                setTimeout(() => clearInterval(timer), 2000);
            }
        }, 500);

        // ===== 再描画追従 =====
        // ココフォリアのUI更新に合わせて幅を復元
        const mo = new MutationObserver(() => {
            if (isDragging) return;

            requestAnimationFrame(() => {
                applyWidth(lastWidth);
                ensureHandle();
            });
        });

        mo.observe(document.body, { childList: true, subtree: true, attributes: true });

        // 初回強制適用
        applyWidth(lastWidth);
        ensureHandle();
    });
}


// ===== 開閉ボタン追従 =====
// チャット開閉時のズレを防ぐ
document.addEventListener("click", (e) => {
    const t = e.target;

    const isToggleClick =
      !!(t && t.closest && (
        t.closest('[data-testid="LastPageIcon"]') ||
        t.closest('[data-testid="FirstPageIcon"]')
      ));

    if (!isToggleClick) return;

    requestAnimationFrame(() => applyWidth(lastWidth));
    requestAnimationFrame(() => ensureHandle());
    setTimeout(() => applyWidth(lastWidth), 250);
}, true);


// ===== 起動 =====
init();


// ===== popup連携 =====
// スライダー操作を受信
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'UPDATE_WIDTH') {
        lastWidth = msg.value;
        applyWidth(msg.value);
    }
});
