document.addEventListener("DOMContentLoaded", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || !tabs[0] || !tabs[0].url) return;
    const currentTab = tabs[0];
    const getRoomId = (url) => {
      const m = url.match(/\/rooms\/([^/]+)/);
      return m ? m[1] : "unknown";
    };
    const roomId = getRoomId(currentTab.url);
    const STORAGE_KEY = `chatWidth_${roomId}`;
    const slider = document.getElementById("widthSlider");
    const display = document.getElementById("display");
    if (!slider || !display) return;

    chrome.storage.local.get([STORAGE_KEY], (res) => {
      const savedWidth = Number(res[STORAGE_KEY] ?? 520);
      slider.value = String(savedWidth);
      display.innerText = String(savedWidth);
    });

    slider.addEventListener("input", () => {
      const val = Number(slider.value);
      display.innerText = String(val);
      chrome.storage.local.set({ [STORAGE_KEY]: val });
      chrome.tabs.sendMessage(currentTab.id, { type: "SET_WIDTH", value: val });
    });
  });
});