const MIN_WIDTH = 280;
const MAX_WIDTH = 1200;
const DEFAULT_WIDTH = 520;

const DRAWER_SELECTOR = ".MuiDrawer-root";
const DRAWER_PAPER_SELECTOR = ".MuiDrawer-paper";
const MAIN_CONTAINER_SELECTOR = ".sc-fneaQi.dtgcZz";

let lastWidth = DEFAULT_WIDTH;

const getRoomId = () => {
    const m = location.pathname.match(/^\/rooms\/([^/]+)/);
    return m ? m[1] : "unknown";
};
const STORAGE_KEY = `chatWidth_${getRoomId()}`;

let resizerStyle = document.getElementById('ccfolia-drag-resizer-style');
if (!resizerStyle) {
    resizerStyle = document.createElement('style');
    resizerStyle.id = 'ccfolia-drag-resizer-style';
    document.head.appendChild(resizerStyle);
}

let isDragging = false;

function applyWidth(px) {
    const w = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, px));

    const paperRight = document.querySelector(".MuiDrawer-paperAnchorRight");
    const rect = paperRight ? paperRight.getBoundingClientRect() : null;
    const isChatOpen = !!rect && rect.left < window.innerWidth - 1;

    const rightW = isChatOpen ? w : 0;

    resizerStyle.innerHTML = `
      .MuiDrawer-paperAnchorRight {
          width: ${w}px !important;
          min-width: ${w}px !important;
          max-width: ${w}px !important;
          flex: 0 0 ${w}px !important;
      }

      .sc-fneaQi.dtgcZz {
          right: ${rightW}px !important;
      }

      header.MuiAppBar-positionFixed .MuiToolbar-root {
          overflow: hidden !important;
          display: flex !important;
          flex-direction: row !important;
      }

      header .sc-hcmsOB {
          flex: 1 1 auto !important;
          min-width: 0 !important;
          width: auto !important;
          max-width: calc(100vw - ${rightW}px - 500px) !important;
      }

      header .sc-hLyjac {
          display: none !important;
      }

      header .sc-kSCeZB, 
      header .sc-havvrs, 
      header .sc-ojjjp, 
      header .sc-cQDEMz,
      header .MuiAvatar-root,
      header button {
          flex-shrink: 0 !important;
      }

      .sc-lMYQj.efVceY { right: 10px !important; left: auto !important; }
      .sc-eSoXjr.gnVibT { right: 20px !important; left: auto !important; }
    `;
    return !!paperRight;
}

function ensureHandle() {
    const paper = document.querySelector(".MuiDrawer-paperAnchorRight");
    if (!paper) return;

    let handle = document.getElementById('ccfolia-chat-resizer-handle');
    if (!handle) {
        handle = document.createElement('div');
        handle.id = 'ccfolia-chat-resizer-handle';
        Object.assign(handle.style, {
            position: 'absolute',
            left: '0',
            top: '0',
            width: '8px',
            height: '100%',
            cursor: 'col-resize',
            zIndex: '9999',
            backgroundColor: 'transparent'
        });

        handle.addEventListener('mousedown', (e) => {
            isDragging = true;
            document.body.style.cursor = 'col-resize';
            document.body.style.userSelect = 'none';

            const onMouseMove = (moveEvent) => {
                const newWidth = window.innerWidth - moveEvent.clientX;
                lastWidth = newWidth;
                applyWidth(newWidth);
            };

            const onMouseUp = () => {
                isDragging = false;
                document.body.style.cursor = '';
                document.body.style.userSelect = '';
                chrome.storage.local.set({ [STORAGE_KEY]: lastWidth });
                document.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseup', onMouseUp);
            };

            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        });

        paper.appendChild(handle);
    }
}

function init() {
    chrome.storage.local.get([STORAGE_KEY], (res) => {
        const savedWidth = res[STORAGE_KEY] || DEFAULT_WIDTH;
        lastWidth = savedWidth;

        const timer = setInterval(() => {
            const success = applyWidth(lastWidth);
            if (success) {
                ensureHandle();
                setTimeout(() => clearInterval(timer), 2000);
            }
        }, 500);

        const mo = new MutationObserver(() => {
            if (isDragging) return;
            requestAnimationFrame(() => {
                applyWidth(lastWidth);
                ensureHandle();
            });
        });

        mo.observe(document.body, { childList: true, subtree: true, attributes: true });

        applyWidth(lastWidth);
        ensureHandle();
    });
}

document.addEventListener("click", (e) => {
    const t = e.target;
    const isToggleClick = !!(t && t.closest && (
        t.closest('[data-testid="LastPageIcon"]') ||
        t.closest('[data-testid="FirstPageIcon"]')
    ));

    if (!isToggleClick) return;

    requestAnimationFrame(() => applyWidth(lastWidth));
    requestAnimationFrame(() => ensureHandle());
    setTimeout(() => applyWidth(lastWidth), 250);
}, true);

init();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "SET_WIDTH") {
        lastWidth = msg.value;
        applyWidth(lastWidth);
        chrome.storage.local.set({ [STORAGE_KEY]: lastWidth });
    }
});