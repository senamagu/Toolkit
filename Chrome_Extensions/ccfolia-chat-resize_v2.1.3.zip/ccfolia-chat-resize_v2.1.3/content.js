const MIN_WIDTH = 280;
const MAX_WIDTH = 1200;
const DEFAULT_WIDTH = 520;

const DRAWER_SELECTOR = ".MuiDrawer-root"; 
const DRAWER_PAPER_SELECTOR = ".MuiDrawer-paper";
const MAIN_CONTAINER_SELECTOR = ".sc-geBDJh.iTYDax";
const HEADER_SPACER_SELECTOR = "header .sc-gJjChS";

let lastWidth = DEFAULT_WIDTH;

const getRoomId = () => {
    const m = location.pathname.match(/^\/rooms\/([^/]+)/);
    return m ? m[1] : "unknown";
};
const STORAGE_KEY = `chatWidth_${getRoomId()}`;

let resizerStyle = document.getElementById('ccfolia-drag-resizer-style');
if (!resizerStyle) {
    resizerStyle = document.createElement('style');
    resizerStyle.id = 'ccfolia-drag-resizer-style';
    document.head.appendChild(resizerStyle);
}

let isDragging = false;

function applyWidth(px) {
    const w = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, px));

    const paperRight = document.querySelector(".MuiDrawer-paperAnchorRight");
    const rect = paperRight ? paperRight.getBoundingClientRect() : null;
    const isChatOpen = !!rect && rect.left < window.innerWidth - 1;

    const rightW = isChatOpen ? w : 0;
    
    resizerStyle.innerHTML = `
      .MuiDrawer-paperAnchorRight:has(form) {
          width: ${w}px !important;
          min-width: ${w}px !important;
          max-width: ${w}px !important;
          flex: 0 0 ${w}px !important;
      }
  
      .sc-geBDJh.iTYDax, .sc-fneaQi.dtgcZz {
          right: ${rightW}px !important;
      }

      header .sc-gJjChS, header .sc-hLyjac {
          width: ${rightW}px !important;
          min-width: ${rightW}px !important;
      }

      .MuiDrawer-paperAnchorRight:has(form) form > div:has(button[type="submit"]) {
          display: flex !important;
          flex-wrap: nowrap !important;
          overflow-x: auto !important;
          overflow-y: hidden !important;
          scrollbar-width: none !important;
          position: relative !important;
      }

      .MuiDrawer-paperAnchorRight:has(form) form > div:has(button[type="submit"])::-webkit-scrollbar {
          display: none !important;
      }

      .MuiDrawer-paperAnchorRight:has(form) button[type="submit"] {
          position: sticky !important;
          right: 0 !important;
          z-index: 10 !important;
          background-color: #272727 !important;
          flex-shrink: 0 !important;
          box-shadow: -8px 0 8px #272727 !important;
      }

      .MuiDrawer-paperAnchorRight:has(form) form > div:has(button[type="submit"]) > * {
          flex-shrink: 0 !important;
      }

      .sc-cxyaiY.cMXExF { right: 10px !important; left: auto !important; }
      .sc-cKhha-d.extLAb, .sc-kMGnbm.bsyoTg { right: 20px !important; left: auto !important; }
  `;

    return document.querySelector(DRAWER_SELECTOR) !== null;
}

const saveWidth = (px) => {
    chrome.storage.local.set({ [STORAGE_KEY]: px });
};

function ensureHandle() {
    if (document.getElementById("cc-chat-drag-handle")) return;

    const chat = document.querySelector(DRAWER_PAPER_SELECTOR) || document.querySelector(DRAWER_SELECTOR);
    if (!chat) return;

    const handle = document.createElement("div");
    handle.id = "cc-chat-drag-handle";
    handle.title = "ドラッグで幅を変更";
    handle.style.cssText = `
        position: absolute;
        top: 0;
        left: -5px;
        width: 10px;
        height: 100%;
        cursor: ew-resize;
        z-index: 10000;
        background: transparent;
    `;
    
    const line = document.createElement("div");
    line.style.cssText = `
        position: absolute;
        left: 4px;
        width: 2px;
        height: 100%;
        background: rgba(255, 255, 255, 0.5);
        opacity: 0;
        transition: opacity 0.2s;
        pointer-events: none;
    `;
    handle.appendChild(line);

    handle.onmouseenter = () => line.style.opacity = "1";
    handle.onmouseleave = () => { if (!isDragging) line.style.opacity = "0"; };

    chat.appendChild(handle);

    const onMouseMove = (e) => {
        if (!isDragging) return;
        const newWidth = window.innerWidth - e.clientX;
        applyWidth(newWidth);
    };

    const onMouseUp = (e) => {
        if (!isDragging) return;
        isDragging = false;
        line.style.opacity = "0";
        document.body.style.cursor = "";
        const finalWidth = window.innerWidth - e.clientX;
        lastWidth = finalWidth;
        saveWidth(finalWidth);
        window.removeEventListener("mousemove", onMouseMove);
        window.removeEventListener("mouseup", onMouseUp);
    };

    handle.addEventListener("mousedown", (e) => {
        e.preventDefault();
        isDragging = true;
        document.body.style.cursor = "ew-resize";
        window.addEventListener("mousemove", onMouseMove);
        window.addEventListener("mouseup", onMouseUp);
    });
}

function init() {
    chrome.storage.local.get([STORAGE_KEY], (res) => {
        const savedWidth = res[STORAGE_KEY] || DEFAULT_WIDTH;
        lastWidth = savedWidth;

        const timer = setInterval(() => {
            const success = applyWidth(lastWidth);
            if (success) {
                ensureHandle();
                setTimeout(() => clearInterval(timer), 2000);
            }
        }, 500);

        const mo = new MutationObserver(() => {
            if (isDragging) return;

            requestAnimationFrame(() => {
                applyWidth(lastWidth);
                ensureHandle();
            });
        });

        mo.observe(document.body, { childList: true, subtree: true, attributes: true });

        applyWidth(lastWidth);
        ensureHandle();
    });
}

document.addEventListener("click", (e) => {
    const t = e.target;

    const isToggleClick =
      !!(t && t.closest && (
        t.closest('[data-testid="LastPageIcon"]') ||
        t.closest('[data-testid="FirstPageIcon"]')
      ));

    if (!isToggleClick) return;

    requestAnimationFrame(() => applyWidth(lastWidth));
    requestAnimationFrame(() => ensureHandle());
    setTimeout(() => applyWidth(lastWidth), 250);
}, true);

init();

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'UPDATE_WIDTH') {
        lastWidth = msg.value;
        applyWidth(msg.value);
    }
});