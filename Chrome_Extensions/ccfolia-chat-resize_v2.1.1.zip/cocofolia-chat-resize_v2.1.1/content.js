

// ===== 設定・定数 =====
// 幅の最小 / 最大 / 初期値
const MIN_WIDTH = 280;
const MAX_WIDTH = 1200;
const DEFAULT_WIDTH = 520;

// チャットUIのセレクタ（ココフォリア更新対策で複数指定）
const DRAWER_SELECTOR = ".MuiDrawer-root"; 
const DRAWER_PAPER_SELECTOR = ".MuiDrawer-paper";
const MAIN_CONTAINER_SELECTOR = ".sc-geBDJh.iTYDax";
const HEADER_SPACER_SELECTOR = "header .sc-gJjChS";

// ===== 保存キー生成 =====
// URLからルームIDを取得
const getRoomId = () => {
    const m = location.pathname.match(/^\/rooms\/([^/]+)/);
    return m ? m[1] : "unknown";
};

// ルームごとの保存キー
const STORAGE_KEY = `chatWidth_${getRoomId()}`;

// ===== スタイルタグ準備 =====
// 幅変更用のCSSを差し込むためのタグを作る
let resizerStyle = document.getElementById('ccfolia-drag-resizer-style');
if (!resizerStyle) {
    resizerStyle = document.createElement('style');
    resizerStyle.id = 'ccfolia-drag-resizer-style';
    document.head.appendChild(resizerStyle);
}

// ===== ドラッグ状態管理 =====
let isDragging = false;

// ===== 幅を適用 =====
// CSSを書き換えてチャット幅を変更
function applyWidth(px) {
    const w = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, px));
    
    resizerStyle.innerHTML = `
        .MuiDrawer-root, .MuiDrawer-paper, .sc-lfRwWD {
            width: ${w}px !important;
            min-width: ${w}px !important;
            max-width: ${w}px !important;
            flex: 0 0 ${w}px !important;
        }
        .sc-geBDJh.iTYDax {
            right: ${w}px !important;
        }
        header .sc-gJjChS {
            width: ${w}px !important;
            min-width: ${w}px !important;
        }
        .sc-cxyaiY.cMXExF { right: 10px !important; left: auto !important; }
        .sc-cKhha-d.extLAb, .sc-kMGnbm.bsyoTg { right: 20px !important; left: auto !important; }
    `;
    return document.querySelector(DRAWER_SELECTOR) !== null;
}

// ===== 幅を保存 =====
const saveWidth = (px) => {
    chrome.storage.local.set({ [STORAGE_KEY]: px });
};

// ===== ドラッグUI生成 =====
// チャット左端にドラッグハンドルを追加
function ensureHandle() {
    if (document.getElementById("cc-chat-drag-handle")) return;

    const chat = document.querySelector(DRAWER_PAPER_SELECTOR) || document.querySelector(DRAWER_SELECTOR);
    if (!chat) return;

    const handle = document.createElement("div");
    handle.id = "cc-chat-drag-handle";
    handle.title = "ドラッグで幅を変更";
    handle.style.cssText = `
        position: absolute;
        top: 0;
        left: -5px;
        width: 10px;
        height: 100%;
        cursor: ew-resize;
        z-index: 10000;
        background: transparent;
    `;
    
    const line = document.createElement("div");
    line.style.cssText = `
        position: absolute;
        left: 4px;
        width: 2px;
        height: 100%;
        background: rgba(255, 255, 255, 0.5);
        opacity: 0;
        transition: opacity 0.2s;
        pointer-events: none;
    `;
    handle.appendChild(line);

    handle.onmouseenter = () => line.style.opacity = "1";
    handle.onmouseleave = () => { if (!isDragging) line.style.opacity = "0"; };

    chat.appendChild(handle);

    // ===== ドラッグ処理 =====
    const onMouseMove = (e) => {
        if (!isDragging) return;
        const newWidth = window.innerWidth - e.clientX;
        applyWidth(newWidth);
    };

    const onMouseUp = (e) => {
        if (!isDragging) return;
        isDragging = false;
        line.style.opacity = "0";
        document.body.style.cursor = "";
        const finalWidth = window.innerWidth - e.clientX;
        saveWidth(finalWidth);
        window.removeEventListener("mousemove", onMouseMove);
        window.removeEventListener("mouseup", onMouseUp);
    };

    handle.addEventListener("mousedown", (e) => {
        e.preventDefault();
        isDragging = true;
        document.body.style.cursor = "ew-resize";
        window.addEventListener("mousemove", onMouseMove);
        window.addEventListener("mouseup", onMouseUp);
    });
}

// ===== 初期化 =====
// 保存された幅を読み込み適用
function init() {
    chrome.storage.local.get([STORAGE_KEY], (res) => {
        const savedWidth = res[STORAGE_KEY] || DEFAULT_WIDTH;
        
        const timer = setInterval(() => {
            const success = applyWidth(savedWidth);
            if (success) {
                ensureHandle();
                if (document.getElementById("cc-chat-drag-handle")) {
                    setTimeout(() => clearInterval(timer), 2000);
                }
            }
        }, 500);
    });
}

init();

// ===== popupからの通知 =====
// スライダー操作時の幅更新を受信
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'UPDATE_WIDTH') applyWidth(msg.value);
});